# Task 4 Deliverables

1. GitHub Repository: https://github.com/ShengyiRuan/ci-helloworld
2. Docker Hub Image: https://hub.docker.com/repository/docker/jensenruan/ci-helloworld
