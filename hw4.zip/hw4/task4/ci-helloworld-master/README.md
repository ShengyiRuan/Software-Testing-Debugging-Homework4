# ci-helloworld

A super simple example showing a fully functioning workflow using Github Actions that includes Build, Test, Code Coverage, Build a docker container image and deploy to Docker Hub.


