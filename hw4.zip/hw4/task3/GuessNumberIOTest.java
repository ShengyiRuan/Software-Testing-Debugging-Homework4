import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertThrows;


public class GuessNumberIOTest {
    // Define strings to simulate interactive input/output for the game
    String firstLine = "A number is chosen between 1 to 100. Guess the number within 5 trials.\n";
    String successLine = "Guess the number: Congratulations! You guessed the number.";
    String endLine = "You have exhausted 5 trials.\n" + "The number was ";
    String lessLine = "Guess the number: The number is less than ";
    String greatLine = "Guess the number: The number is greater than ";

    @Test // result is 50, guess is "7 88 95 23 35", guess is incorrect
    public void FiveTrailsNotRight_test01() {
        //random set
        Random rnd = new Random() {
            @Override
            public int nextInt(int bound) {
                return 50; // Mocking a random number
            }
        };
        // Prepare input stream with test data and corresponding byte array
        String strData = "7 88 95 23 35";
        String[] lst = strData.split(" ");
        byte[] data = strData.getBytes(StandardCharsets.UTF_8);
        // Change the System IO
        BufferedInputStream in = new BufferedInputStream(new ByteArrayInputStream(data));
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintStream output = new PrintStream(out);
        System.setIn(in); System.setOut(output);
        // Run the function and get output
        int result = GuessNumber.guessingNumberGame(rnd);
        String string = out.toString();

        StringBuilder expected = new StringBuilder(firstLine);
        for (int i = 0; i < lst.length; i++){
            int num = Integer.parseInt(lst[i]);
            if (num < result){
                expected.append(greatLine).append(Integer.toString(num)).append("\n");
                if (i == lst.length - 1){
                    expected.append(endLine).append(Integer.toString(result)).append("\n");
                    break;
                }
            }
            else if (num > result){
                expected.append(lessLine).append(Integer.toString(num)).append("\n");
                if (i == lst.length - 1){
                    expected.append(endLine).append(Integer.toString(result)).append("\n");
                    break;
                }
            } else {
                expected.append(successLine).append("\n");
                break;
            }
        }
        // Assert
        Assertions.assertEquals(expected.toString(), string);
        // Change back the System IO
        System.setIn(System.in); System.setOut(System.out);
    }

    @Test // result is 51,  guess "51", guess is right
    public void GuessRightWithinFiveTrials_Test02() {
        //random set
        Random rnd = new Random() {
            @Override
            public int nextInt(int bound) {
                return 50; // Mocking a random number
            }
        };
        // Set up the input
        String strData = "42 33 24 78 51";
        String[] lst = strData.split(" ");
        byte[] data = strData.getBytes(StandardCharsets.UTF_8);
        // Change the System IO
        BufferedInputStream in = new BufferedInputStream(new ByteArrayInputStream(data));
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintStream output = new PrintStream(out);
        System.setIn(in); System.setOut(output);
        // Run the function and get output
        int result = GuessNumber.guessingNumberGame(rnd);
        String string = out.toString();

        StringBuilder expected = new StringBuilder(firstLine);
        for (int i = 0; i < lst.length; i++){
            int num = Integer.parseInt(lst[i]);
            if (num < result){
                expected.append(greatLine).append(Integer.toString(num)).append("\n");
                if (i == lst.length - 1){
                    expected.append(endLine).append(Integer.toString(result)).append("\n");
                    break;
                }
            }
            else if (num > result){
                expected.append(lessLine).append(Integer.toString(num)).append("\n");
                if (i == lst.length - 1){
                    expected.append(endLine).append(Integer.toString(result)).append("\n");
                    break;
                }
            } else {
                expected.append(successLine).append("\n");
                break;
            }
        }
        // Assert
        Assertions.assertEquals(expected.toString(), string);
        // Change back the System IO
        System.setIn(System.in); System.setOut(System.out);
    }

    @Test // result is 51,  guess is "51", guess right
    public void FirstTryRight_Test03() {
        //random set
        Random rnd = new Random() {
            @Override
            public int nextInt(int bound) {
                return 50; // Mocking a random number
            }
        };
        // Set up the input
        String strData = "51";
        String[] lst = strData.split(" ");
        byte[] data = strData.getBytes(StandardCharsets.UTF_8);
        // Change the System IO
        BufferedInputStream in = new BufferedInputStream(new ByteArrayInputStream(data));
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintStream output = new PrintStream(out);
        System.setIn(in); System.setOut(output);
        // Run the function and get output
        int result = GuessNumber.guessingNumberGame(rnd);
        String string = out.toString();

        StringBuilder expected = new StringBuilder(firstLine);
        for (int i = 0; i < lst.length; i++){
            int num = Integer.parseInt(lst[i]);
            if (num < result){
                expected.append(greatLine).append(Integer.toString(num)).append("\n");
                if (i == lst.length - 1){
                    expected.append(endLine).append(Integer.toString(result)).append("\n");
                    break;
                }
            }
            else if (num > result){
                expected.append(lessLine).append(Integer.toString(num)).append("\n");
                if (i == lst.length - 1){
                    expected.append(endLine).append(Integer.toString(result)).append("\n");
                    break;
                }
            } else {
                expected.append(successLine).append("\n");
                break;
            }
        }
        // Assert
        Assertions.assertEquals(expected.toString(), string);
        // Change back the System IO
        System.setIn(System.in); System.setOut(System.out);
    }

    @Test // result is 51,  guess is "abc", throws exception right
    public void InvalidInputType_Test04() {
        //random set
        Random rnd = new Random() {
            @Override
            public int nextInt(int bound) {
                return 50; // Mocking a random number
            }
        };
        // Set up the input
        String strData = "abc";
        String[] lst = strData.split(" ");
        byte[] data = strData.getBytes(StandardCharsets.UTF_8);
        // Change the System IO
        BufferedInputStream in = new BufferedInputStream(new ByteArrayInputStream(data));
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintStream output = new PrintStream(out);
        System.setIn(in); System.setOut(output);
        // Run the function and Assert
        assertThrows(InputMismatchException.class, ()->{GuessNumber.guessingNumberGame(rnd);});
        // Change back the System IO
        System.setIn(System.in); System.setOut(System.out);
    }

    @Test
    // This one didn't pass
    // Expected to throw InputMismatchException when the user input value is not between [1,100], but didn't
    // Reason is missing the check for user input range
    public void BeyondBound_Test05() {
        //random set
        Random rnd = new Random() {
            @Override
            public int nextInt(int bound) {
                return 50; // Mocking a random number
            }
        };
        // Set up the input
        String strData = "101";
        String[] lst = strData.split(" ");
        byte[] data = strData.getBytes(StandardCharsets.UTF_8);
        // Change the System IO
        BufferedInputStream in = new BufferedInputStream(new ByteArrayInputStream(data));
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintStream output = new PrintStream(out);
        System.setIn(in); System.setOut(output);
        // Run the function and get output and Assert
        assertThrows(InputMismatchException.class, ()-> GuessNumber.guessingNumberGame(rnd));
        // Change back the System IO
        System.setIn(System.in); System.setOut(System.out);
    }

    @Test // result is 1, guess is "3 4 5 1.0", guess is incorrect
    public void NotIntNum_test06() {
        //random set
        Random rnd = new Random() {
            @Override
            public int nextInt(int bound) {
                return 0; // Mocking a random number
            }
        };
        // Set up the input
        String strData = "7 4 5 1.0";
        String[] lst = strData.split(" ");
        byte[] data = strData.getBytes(StandardCharsets.UTF_8);
        // Change the System IO
        BufferedInputStream in = new BufferedInputStream(new ByteArrayInputStream(data));
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintStream output = new PrintStream(out);
        System.setIn(in); System.setOut(output);
        // Run the function and get output and assert
        assertThrows(InputMismatchException.class, ()-> GuessNumber.guessingNumberGame(rnd));
        // Change back the System IO
        System.setIn(System.in); System.setOut(System.out);
    }
}
