import org.junit.jupiter.api.Test;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class GuessNumberRandomnessTest {

    // This test assesses the randomness of the number generation process.
    // It ensures that over a large number of trials, the number distribution approximates a uniform distribution.
    @Test
    public void testRandomness() {
        HashMap<Integer, Integer> frequencyMap = new HashMap<>();
        Random rnd = new Random(0); // Seeded to ensure repeatability of the test
        for (int i = 0; i < 30000; i++) {
            // Setup test inputs as a sequence of guesses
            String strData = "9 10 75 85 35";
            byte[] data = strData.getBytes(StandardCharsets.UTF_8);

            // Redirect system input and output to capture results
            BufferedInputStream in = new BufferedInputStream(new ByteArrayInputStream(data));
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            PrintStream output = new PrintStream(out);
            System.setIn(in);
            System.setOut(output);

            // Execute the function and store the result
            int result = GuessNumber.guessingNumberGame(rnd);
            frequencyMap.merge(result, 1, Integer::sum);
        }

        // Reset system input and output to their original sources
        System.setIn(System.in);
        System.setOut(System.out);

        // Convert frequency map to an array for easier analysis
        Integer[] frequencies = new Integer[100];
        frequencyMap.forEach((key, value) -> frequencies[key - 1] = value);

        // Verify that the generated numbers fall within an acceptable frequency range
        for (int j = 0; j < 100; j++) {
            double expectedFrequency = 300.0; // Expected frequency per number if evenly distributed
            double actualFrequency = frequencies[j]; // Actual observed frequency
            // The acceptable range is chosen to be ±50% of the expected frequency for this test
            assertTrue(actualFrequency >= expectedFrequency * 0.5 && actualFrequency <= expectedFrequency * 1.5,
                    "The frequency of number " + (j + 1) + " deviates significantly from uniform distribution.");
        }
    }
}
