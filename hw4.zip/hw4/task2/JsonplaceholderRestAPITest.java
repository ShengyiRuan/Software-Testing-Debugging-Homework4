import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class JsonplaceholderRestAPITest {

    @BeforeAll
    public static void setUp() {
        RestAssured.baseURI = "https://jsonplaceholder.typicode.com";
    }

    @Test
    public void testAlbumEndpoint_containsTitle() {
        given()
                .when().get("/albums")
                .then()
                .assertThat()
                .body("title", hasItem("omnis laborum odio"));
    }

    @Test
    public void testCommentsEndpoint_containsAtLeast200Comments() {
        given()
                .when().get("/comments")
                .then()
                .assertThat()
                .body("size()", greaterThanOrEqualTo(200));
    }

    @Test
    public void testUsersEndpoint_containsUser() {
        given()
                .when().get("/users")
                .then()
                .assertThat()
                .body("findAll { it.name == 'Ervin Howell' }.username", hasItem("Antonette"))
                .body("findAll { it.name == 'Ervin Howell' }.address.zipcode", hasItem("90566-7771"));
    }

    @Test
    public void testCommentsEndpoint_containsBizEmails() {
        given()
                .when().get("/comments")
                .then()
                .assertThat()
                .body("email.any { it.endsWith('.biz') }", equalTo(true));
    }

    @Test
    public void testCreatePostEndpoint() {
        String requestBody = "{\"userId\": 11,\"id\": 101,\"title\": \"sunt aut facere repellat provident occaecati excepturi optio reprehenderit\",\"body\": \"quia et suscipit suscipit recusandae consequuntur expedita et cum reprehenderit molestiae ut ut quas totam nostrum rerum est autem sunt rem eveniet architecto\"}";

        given()
                .contentType("application/json")
                .body(requestBody)
                .when().post("/posts")
                .then()
                .statusCode(201);
    }
}
